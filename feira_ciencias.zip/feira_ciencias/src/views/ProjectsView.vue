<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import api from '../assets/plugins/axios.js'
import { useNotificationStore } from '@/stores/notification'
import CrudModal from '@/components/CrudModal.vue';
import { useEventoStore } from '@/stores/eventoStore'
import { storeToRefs } from 'pinia'
import ProjectCard from '@/components/ProjectCard.vue'


const router = useRouter();
const notificationStore = useNotificationStore();
const eventoStore = useEventoStore();
const { eventos } = storeToRefs(eventoStore);

// --- ESTADO DA PÁGINA ---
const carregando = ref(true)
const erro = ref(null)
const todosProjetos = ref([])
const filtroStatus = ref('Todos')
const nomeUsuario = ref('')
let userId = null;
const avaliadores = ref([]);
const totalProjetosAprovados = ref(0)

// --- ESTADO PARA O MODAL ---
const isModalOpen = ref(false)
const isModalLoading = ref(false)
const currentItem = ref(null) // Guarda o item para edição (null para criação)

// --- ESTADO PARA O MODAL DE EXCLUSÃO ---
const isDeleteModalOpen = ref(false);
const projectToDelete = ref(null); // Guarda o item para exclusão

const userDataString = sessionStorage.getItem('user_data');
if (userDataString) {
  const userData = JSON.parse(userDataString);
  nomeUsuario.value = userData.user.nome;
  userId = userData.user.id_usuario;
}

const modalConfig = computed(() => ({
  title: currentItem.value ? 'Editar Projeto' : 'Novo Projeto',
  fields: [
    {
      key: 'id_evento',
      label: 'Evento Associado',
      type: 'select',
      items: eventos.value.map(evento => ({
        title: evento.nome,
        value: evento.id_evento,
      })),
      rules: [v => !!v || 'É necessário selecionar um evento'],
    },
    {
      key: 'titulo',
      label: 'Título do Projeto',
      type: 'text',
      rules: [v => !!v || 'O título é obrigatório'],
    },
    {
      key: 'problema',
      label: 'Problema a ser Resolvido',
      type: 'textarea',
      rules: [v => !!v || 'A descrição do problema é obrigatória'],
    },
    {
      key: 'relevancia',
      label: 'Relevância do Projeto',
      type: 'textarea',
      rules: [v => !!v || 'A relevância é obrigatória'],
    },
    {
      key: 'id_orientador',
      label: 'Professor orientador',
      type: 'select',
      items: avaliadores.value.map(avaliador => ({
        title: avaliador.nome,
        value: avaliador.id_usuario,
      })),
      rules: [v => !!v || 'O Orientador é obrigatório'],
    },
    {
      key: 'id_coorientador',
      label: 'Professor coorientador',
      type: 'select',
      items: avaliadores.value.map(avaliador => ({
        title: avaliador.nome,
        value: avaliador.id_usuario,
      })),
      rules: [v => !!v || 'O Corientador é obrigatório'],
    },
  ],
}));

const opcoesStatus = [
  { title: 'Todos', value: 'Todos' },
  { title: 'Em Elaboração', value: 1 },
  { title: 'Reprovado', value: 3 },
]
const statusMap = {
  1: { text: 'Em Elaboração', color: 'orange-darken-2' },
  3: { text: 'Reprovado', color: 'red-darken-2' },
  4: { text: 'Reprovado com Ressalvas', color: 'orange-darken-2' },
}

// --- MÉTODOS ---
onMounted(async () => {
  if (!userId) {
    erro.value = "Usuário não encontrado. Por favor, faça o login novamente.";
    carregando.value = false;
    return;
  }

  const fetchProjetosPromise = api.get(`/projetos?id_responsavel=${userId}&situacao_not=2`); // Busca todos os projetos do usuário com qualquer status
  const fetchEventosPromise = eventoStore.fetchEventos();
  const fetchAvaliadoresPromise = api.get(`/usuarios?id_tipo_usuario=3`); //lista os avaliadores
  const fetchAprovadosCountPromise = api.get(`/projetos?id_responsavel=${userId}&id_situacao=2`);

   try {

    const results = await Promise.allSettled([
      fetchProjetosPromise,
      fetchAvaliadoresPromise,
      fetchEventosPromise,
      fetchAprovadosCountPromise
    ]);

    const [projetosResult, avaliadoresResult, eventosResult, aprovadosCountResult] = results;

    if (projetosResult.status === 'fulfilled') {
      todosProjetos.value = projetosResult.value.data;
    } else {
      console.error("Erro ao buscar projetos:", projetosResult.reason);
      todosProjetos.value = [];
    }

    if (avaliadoresResult.status === 'fulfilled') {
      avaliadores.value = avaliadoresResult.value.data;
      console.log("Avaliadores carregados:", avaliadores.value);
    } else {
        console.error("Erro ao buscar avaliadores:", avaliadoresResult.reason);
    }
    if (aprovadosCountResult.status === 'fulfilled') {
      totalProjetosAprovados.value = aprovadosCountResult.value.data.length;
    } else {
      console.error("Erro ao buscar contagem de aprovados:", aprovadosCountResult.reason);
    }

    if (eventosResult.status === 'rejected') {
        console.error("Erro ao buscar eventos:", eventosResult.reason);
    }

  } catch (geralError) {
    console.error("Ocorreu um erro inesperado:", geralError);
    erro.value = "Não foi possível carregar os dados da página.";
  } finally {
    carregando.value = false;
  }
});

// --- MÉTODOS PARA MODAIS ---

const openCreateModal = () => {
  currentItem.value = null;
  isModalOpen.value = true;
};

const openEditModal = (projeto) => {
  currentItem.value = { ...projeto }; // Copia o objeto para evitar mutação direta
  isModalOpen.value = true;
};

const openDeleteModal = (projeto) => {
  projectToDelete.value = projeto; // Guarda o projeto a ser excluído
  isDeleteModalOpen.value = true;
};


const handleSave = async (formData) => {
  isModalLoading.value = true;
  
  if (!formData.id_projeto) {
      formData.id_responsavel = userId;
      formData.id_situacao = 1;
  }

  try {
    if (formData.id_projeto) {
      const { data } = await api.put(`/projetos/${formData.id_projeto}`, formData);
      const index = todosProjetos.value.findIndex(p => p.id_projeto === data.id_projeto);
      if (index !== -1) todosProjetos.value.splice(index, 1, data);
      notificationStore.showSuccess('Projeto alterado com sucesso!');
    } else {
      const { data } = await api.post('/projetos', formData);
      todosProjetos.value.push(data);
      notificationStore.showSuccess('Projeto criado com sucesso!');
    }
    isModalOpen.value = false;
  } catch (error) {
    console.error("Erro ao salvar o projeto:", error);
    notificationStore.showError('Ocorreu um erro ao salvar o projeto.');
  } finally {
    isModalLoading.value = false;
  }
};

const handleDelete = async () => {
  if (!projectToDelete.value) return;

  isModalLoading.value = true;
  try {
    await api.delete(`/projetos/${projectToDelete.value.id_projeto}`);
    
    // Remove o projeto da lista local para atualizar a UI
    const index = todosProjetos.value.findIndex(p => p.id_projeto === projectToDelete.value.id_projeto);
    if (index !== -1) {
      todosProjetos.value.splice(index, 1);
    }
    
    notificationStore.showSuccess('Projeto excluído com sucesso!');
    isDeleteModalOpen.value = false;
    projectToDelete.value = null; // Limpa a referência

  } catch (err) {
    console.error("Erro ao excluir o projeto:", err);
    notificationStore.showError('Ocorreu um erro ao excluir o projeto.');
  } finally {
    isModalLoading.value = false;
  }
};


// --- COMPUTED PROPERTIES ---

const projetosFiltrados = computed(() => {
  if (filtroStatus.value === 'Todos' || !filtroStatus.value) {
    return todosProjetos.value
  }
  return todosProjetos.value.filter(p => p.id_situacao === filtroStatus.value)
})

const totalProjetos = computed(() => todosProjetos.value.length)

function goToProjectDetails(id){
  router.push(`/projetos/${id}`)
}
function goToApprovedProjects() {
  router.push('/projetos/aprovados')
}
</script>

<template>
  <v-container fluid>
    <v-row class="mb-8">
      <v-col cols="12" sm="6" md="4">
        <v-card color="green-darken-4" dark class="d-flex flex-column" height="100%">
          <v-card-text>
            <div class="d-flex align-center">
              <v-icon size="48" class="mr-4">mdi-plus-box-multiple</v-icon>
              <div>
                <div class="text-h5 font-weight-bold">Novo Projeto</div>
                <div class="text-subtitle-1">Inicie uma nova proposta</div>
              </div>
            </div>
          </v-card-text>
          <v-spacer></v-spacer>
          <v-card-actions>
            <v-btn variant="outlined" block @click="openCreateModal">Criar agora</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
      <v-col cols="12" sm="6" md="4">
        <v-card variant="tonal" color="grey-darken-1" class="d-flex flex-column" height="100%">
          <v-card-text>
            <div class="d-flex align-center">
              <v-icon size="48" class="mr-4">mdi-folder-account-outline</v-icon>
              <div>
                <div class="text-h4 font-weight-bold text-grey-darken-4">{{ totalProjetos }}</div>
                <div class="text-subtitle-2 text-grey-darken-2">Projetos Registrados</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
      <v-col cols="12" sm="6" md="4">
        <v-card
          variant="tonal"
          color="green-darken-2"
          class="d-flex flex-column"
          height="100%"
          hover
          @click="goToApprovedProjects"
        >
          <v-card-text>
            <div class="d-flex align-center">
              <v-icon size="48" class="mr-4">mdi-check-decagram-outline</v-icon>
              <div>
                <div class="text-h4 font-weight-bold text-green-darken-4">{{ totalProjetosAprovados }}</div>
                <div class="text-subtitle-2 text-green-darken-3">Projetos Aprovados</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-divider class="my-6"></v-divider>
    <v-row align="center" class="mb-4">
      <v-col cols="12" md="6">
        <h2 class="text-h5 font-weight-bold text-grey-darken-4">Meus Projetos</h2>
        <p class="text-subtitle-2 text-grey-darken-1">Gerencie e acompanhe o andamento de suas propostas.</p>
      </v-col>
      <v-col cols="12" md="6" class="d-flex justify-md-end">
        <v-select
          v-model="filtroStatus"
          :items="opcoesStatus"
          label="Filtrar por Status"
          variant="outlined"
          density="compact"
          hide-details
          clearable
          style="max-width: 280px;"
        ></v-select>
      </v-col>
    </v-row>
    
    <v-row v-if="carregando">
      <v-col v-for="n in 3" :key="n" cols="12" sm="6" lg="4">
        <v-skeleton-loader type="image, article, actions"></v-skeleton-loader>
      </v-col>
    </v-row>
    <v-row v-else-if="projetosFiltrados.length === 0">
      <v-col cols="12">
        <v-card flat border class="text-center pa-8">
          <v-icon size="60" class="mb-4 text-grey-lighten-1">mdi-folder-search-outline</v-icon>
          <p class="text-grey-darken-1">Nenhum projeto encontrado.</p>
        </v-card>
      </v-col>
    </v-row>

    <v-row v-else>
      <v-col v-for="projeto in projetosFiltrados" :key="projeto.id_projeto" cols="12" sm="6" lg="4">
        <ProjectCard
          :projeto="projeto"
          @ver-detalhes="goToProjectDetails"
        >
          <template #actions>
            <v-btn icon="mdi-pencil" variant="text" size="small" @click="openEditModal(projeto)"></v-btn>
            <v-btn icon="mdi-delete" variant="text" color="grey" size="small" @click="openDeleteModal(projeto)"></v-btn>
          </template>
        </ProjectCard>
      </v-col>
    </v-row>

    <CrudModal
      v-model="isModalOpen"
      :title="modalConfig.title"
      :fields="modalConfig.fields"
      :item="currentItem"
      :loading="isModalLoading"
      @save="handleSave"
    />
    
    <v-dialog v-model="isDeleteModalOpen" max-width="450">
      <v-card prepend-icon="mdi-alert-circle-outline" title="Confirmar Exclusão">
        <v-card-text>
          Você tem certeza que deseja excluir o projeto <strong>{{ projectToDelete?.titulo }}</strong>? Esta ação não pode ser desfeita.
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn @click="isDeleteModalOpen = false" :disabled="isModalLoading">Cancelar</v-btn>
          <v-btn color="red-darken-2" variant="flat" @click="handleDelete" :loading="isModalLoading">
            Excluir
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<style scoped>
.v-card-title.text-wrap {
  white-space: normal;
  line-height: 1.3em;
  font-weight: 500;
}
.v-card-text {
  min-height: 60px;
}
</style>
